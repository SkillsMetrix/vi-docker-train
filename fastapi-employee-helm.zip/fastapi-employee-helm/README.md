# fastapi-employee Helm chart

This chart packages the working FastAPI + MySQL EKS demo:
- FastAPI Deployment (2 replicas)
- MySQL Deployment
- ConfigMap
- Secret
- PV/PVC using hostPath
- MySQL ClusterIP Service
- FastAPI LoadBalancer Service
- MySQL NetworkPolicy
- FastAPI securityContext
- readiness/liveness probes
- MySQL nodeSelector: country=usa

## Validate before installing

helm lint .

helm template employee-app . --debug

## Install

helm install employee-app .

## Verify

kubectl get pods
kubectl get pv,pvc
kubectl get svc
kubectl get networkpolicy

## Upgrade example

Change fastapi.replicas in values.yaml from 2 to 3:

helm upgrade employee-app .

## Inspect Helm

helm list
helm get values employee-app
helm get manifest employee-app

## Important for the existing demo

The existing non-Helm resources use names such as mysql-pv/mysql-pvc.
This chart intentionally prefixes resources with the Helm release name
(e.g. employee-app-mysql-pv) so it does not collide with them.

Because this is hostPath storage, the MySQL pod must run on a node where
/data/mysql is available. The demo uses nodeSelector country=usa and is
intended for the same training cluster where the working non-Helm demo
was validated.

For a clean Helm demonstration, do not run the Helm chart against the
existing MySQL deployment while both point at the same /data/mysql directory.
Use a fresh/clean demo namespace or remove the old demo resources first.
